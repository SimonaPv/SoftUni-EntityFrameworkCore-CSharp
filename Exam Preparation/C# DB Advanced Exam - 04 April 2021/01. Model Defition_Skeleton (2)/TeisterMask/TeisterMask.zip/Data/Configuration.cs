﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=SIMONAS-LAPTOP\SQLEXPRESS;Database=TeisterMask;Integrated Security=True;TrustServerCertificate=True";
    }
}
