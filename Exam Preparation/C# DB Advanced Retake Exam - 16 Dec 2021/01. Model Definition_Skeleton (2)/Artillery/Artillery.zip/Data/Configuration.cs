﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=SIMONAS-LAPTOP\SQLEXPRESS;Database=Artillery;Integrated Security=True;TrustServerCertificate=True";
    }
}
