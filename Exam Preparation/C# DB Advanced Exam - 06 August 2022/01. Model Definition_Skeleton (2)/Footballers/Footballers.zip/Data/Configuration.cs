﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=SIMONAS-LAPTOP\SQLEXPRESS;Database=Footballers;Integrated Security=True;TrustServerCertificate=True";
    }
}
